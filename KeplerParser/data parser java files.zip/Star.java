package KeplerParser;
import java.io.*;
import java.util.*;

public class Star {
	Scanner scan;
	File starFile;
	public String[] metadata = new String[50];
	ArrayList<DataPoint> data = new ArrayList<DataPoint>();
	int numData;
	private Scanner s2;
	
	/**
	 * creates a new star from the given file 
	 * @param fileLoc the location of the file containing the Kepler data for a given star
	 */
	public Star(String fileLoc){
		starFile = new File(fileLoc);
		starInit();
	}
	
	/**
	 * creates a new star from the given file 
	 * @param fileLoc the file containing the Kepler data for a given star
	 */
	public Star(File fileLoc){
		starFile = fileLoc;
		starInit();
	}
	
	/**
	 * creates a new set of star data
	 */
	public void starInit(){
		
		try{
			scan = new Scanner(starFile);
		}catch(IOException ioe){
			System.out.println("Error. File not found!" + ioe.getMessage());
		}
		
		String line;
		
		//loop for metadata
		for (int i=0; i<50; i++){
			line = scan.nextLine();
			if(line.charAt(0) == '#'){
				metadata[i] = line.substring(1);
			}
			else{
				break;
			}
		}
		
		//parsing data into a DataPoint class

		while(scan.hasNext()){
					line = scan.nextLine();
					s2 = new Scanner(line);
					
					double t = s2.nextDouble();
					double timc = toDouble(s2.next());
					int cad = s2.nextInt();
					double sf = toDouble(s2.next());
					double sfe = toDouble(s2.next());
					double pf= toDouble(s2.next());
					double pfe= toDouble(s2.next());
					double sq= s2.nextDouble();
					double mc1= s2.nextDouble();
					double mc1e= toDouble(s2.next());
					double mc2= s2.nextDouble();
					double mc2e= toDouble(s2.next());
					double pc1= s2.nextDouble();
					double pc2= s2.nextDouble(); 
					s2.close();
					
					data.add(new DataPoint(t, timc, cad, sf, sfe, pf, pfe, sq, mc1, mc1e, mc2, mc2e, pc1, pc2));
				}
		scan.close();

		
//		for(DataPoint dp : data){
			//System.out.println(dp.toString());
//			System.out.println(dp.getSapFlux());
//		}
		
		
		
		numData = data.size();
		//loop to initialize DataPoints
	}
	
	/**
	 * converts a value such as 1.2277194e+04 to a double such as 1227.7194
	 * @param s a string containing a number in scientific notation denoted by e
	 * @return the double resulting from the scientific number
	 */
	public double toDouble(String s){
		int point = s.indexOf('e');
		double value, times;
		value = Double.parseDouble(s.substring(0, point));
		times = Double.parseDouble(s.substring(point+1, s.length()));
		
		value = value * Math.pow(10, times);
		
		//value = (double)Math.round(value * 1000000000) / 1000000000;
		String valString = String.valueOf(value);
		int i = valString.indexOf("000");
		if(i==-1)
			i = valString.indexOf("999");
		if(i != -1)
			value = Double.parseDouble(valString.substring(0, i));
		
		return value;
	}
	
	public DataPoint dataAtTime(double t){
		return null;
	}
	
	public ArrayList<DataPoint> getData(){
		return data;
	}
	
	public int size(){
		return numData;
	}
	
}
